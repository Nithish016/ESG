package p1;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        try {
            // Database connection details
            String url = "jdbc:mysql://localhost:3306/user1";
            String username = "root";
            String dbPassword = "tiger";
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(url, username, dbPassword)) {
                
                // Insert new user into the database
                String insertSql = "INSERT INTO user1 (email, password, role) VALUES (?, ?, ?)";
                try (PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
                    pstmt.setString(1, email);
                    pstmt.setString(2, password);
                    pstmt.setString(3, role);
                    pstmt.executeUpdate();

                    // Display success message
                    response.setContentType("text/html");
                    response.getWriter().println("<html><body>");
                    response.getWriter().println("<h2>Successfully registered new institution!</h2>");
                    response.getWriter().println("<a href='newregister.html'>Go back to registration</a>");
                    response.getWriter().println("</body></html>");
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.setContentType("text/html");
            response.getWriter().println("<html><body>");
            response.getWriter().println("<h2>Error during registration: " + e.getMessage() + "</h2>");
            response.getWriter().println("<a href='newregister.html'>Go back to registration</a>");
            response.getWriter().println("</body></html>");
        }
    }
}