package p1;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/saveFeedback")
public class SaveFeedback extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
        throws ServletException, IOException {
        String dbUrl = "jdbc:mysql://localhost:3306/esg_platform";
        String dbUser = "root";
        String dbPassword = "tiger";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
            
            String sql = "UPDATE documents SET rating_e = ?, rating_s = ?, rating_g = ?, feedback = ? WHERE college_name = ?";
            
            for (String collegeName : request.getParameterMap().keySet()) {
                if (collegeName.startsWith("rating_e")) {
                    String actualCollegeName = collegeName.substring(8);
               
                    String ratingE = request.getParameter("rating_e" + actualCollegeName);
                    String ratingS = request.getParameter("rating_s" + actualCollegeName);
                    String ratingG = request.getParameter("rating_g" + actualCollegeName);
                    String feedback = request.getParameter("feedback" + actualCollegeName);
                    
                    pstmt = conn.prepareStatement(sql);
                    pstmt.setInt(1, Integer.parseInt(ratingE));
                    pstmt.setInt(2, Integer.parseInt(ratingS));
                    pstmt.setInt(3, Integer.parseInt(ratingG));
                    pstmt.setString(4, feedback);
                    pstmt.setString(5, actualCollegeName);
                    pstmt.executeUpdate();
                }
            }
            
            // Redirect to feedback.jsp after successful submission
            response.sendRedirect("feedback.jsp");
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) { }
            try { if (conn != null) conn.close(); } catch (Exception e) { }
        }
    }
}
