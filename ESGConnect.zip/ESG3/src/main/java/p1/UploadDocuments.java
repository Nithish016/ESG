package p1;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.nio.file.Paths;

@SuppressWarnings("serial")
@WebServlet("/uploadDocuments")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
        maxFileSize = 1024 * 1024 * 10,      // 10MB
        maxRequestSize = 1024 * 1024 * 50)   // 50MB
public class UploadDocuments extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/esg_platform";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "tiger";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String collegeName = request.getParameter("collegeName");
        Part filePart = null;
        String message = "";
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            filePart = request.getPart("fileUpload");
            System.out.println("File part: " + filePart);
        } catch (IllegalStateException | ServletException | IOException e) {
            e.printStackTrace();
            response.getWriter().write(createResponseHtml("<p class='error-message'>File upload error. Please try again.</p>"));
            return;
        }

        try {
            if (collegeName != null && !collegeName.isEmpty() && filePart != null && filePart.getSize() > 0) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

                String uploadDirectory = getServletContext().getRealPath("/") + "uploads";
                File uploadDir = new File(uploadDirectory);
                if (!uploadDir.exists()) uploadDir.mkdir();

                String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
                String filePath = uploadDirectory + File.separator + fileName;

                try (InputStream fileContent = filePart.getInputStream()) {
                    Files.copy(fileContent, new File(filePath).toPath(), StandardCopyOption.REPLACE_EXISTING);
                }

                String relativeFilePath = "uploads/" + fileName;
                String sql = "INSERT INTO documents (college_name, file_name) VALUES (?, ?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, collegeName);
                pstmt.setString(2, relativeFilePath);
                pstmt.executeUpdate();

                message = "<p class='success-message'>You have successfully uploaded your document!</p>";
            } else {
                message = "<p class='error-message'>Please provide all details and upload a file.</p>";
            }

        } catch (Exception e) {
            e.printStackTrace();
            message = "<p class='error-message'>An error occurred: " + e.getMessage() + "</p>";
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().write(createResponseHtml(message));
    }

    private String createResponseHtml(String message) {
        return "<!DOCTYPE html><html><head><title>Upload ESG Document</title>"
                + "<style>body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }"
                + "html, body { height: 100%; margin: 0; display: flex; justify-content: center; align-items: center; }"
                + ".container { text-align: center; }"
                + ".success-message { color: green; font-size: 20px; font-weight: bold; }"
                + ".error-message { color: red; font-size: 18px; }"
                + ".button-container { margin-top: 20px; }"
                + ".dashboard-btn { padding: 10px 20px; background-color: #4CAF50; color: white; border: none; cursor: pointer; font-size: 16px; }"
                + ".dashboard-btn:hover { background-color: #45a049; }</style></head>"
                + "<body><div class='container'>" + message
                + "<div class='button-container'><a href='collegedashboard.jsp'><button class='dashboard-btn'>Go Back to Dashboard</button></a></div>"
                + "</div></body></html>";
    }
}
