package p1;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@SuppressWarnings("serial")
@WebServlet("/LoginServlet")
public class User extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String em = request.getParameter("email");
        String pn = request.getParameter("password");
        
        try {
            // Database connection details
            String url = "jdbc:mysql://localhost:3306/user1";
            String username = "root";
            String password = "tiger";
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(url, username, password)) {
                
                // Select the user from the database and check their role
                String selectSql = "SELECT role FROM user1 WHERE email = ? AND password = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(selectSql)) {
                    pstmt.setString(1, em);
                    pstmt.setString(2, pn);
                    try (ResultSet rs = pstmt.executeQuery()) {
                        if (rs.next()) {
                            String role = rs.getString("role").trim(); // Trim to remove any extra spaces
                            System.out.println("User role: " + role); // Log for debugging
                            
                            // Redirect based on user role
                            if ("Admin".equalsIgnoreCase(role)) {
                                response.sendRedirect("admindashboard.jsp");
                            } else {
                                response.sendRedirect("uploadcheck.jsp");
                            }
                        } else {
                            // Invalid credentials, redirect to login or show error
                            response.getWriter().println("Invalid email or password.");
                        }
                    }
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.getWriter().println("Database connection error: " + e.getMessage());
        }
    }
}